const dropdown = document.querySelectorAll(".dropdown");
const selectBox = document.querySelectorAll(".dropdown .select");
const selectTigger = document.querySelectorAll(".select-trigger");
selectTigger.forEach((value, index) => {
    selectTigger[index].onclick = () => {
        selectBox[index].children[1].style.display = "block";
        for (let i = 0; i < selectBox.length; i++) {
            if (i != index) selectBox[i].children[1].style.display = "none";
        }
    };
    // selectBox[index].onmouseout = () => {
    //     selectBox[index].children[1].style.display = "none";
    // };

    let options = selectBox[index].children[1].children;
    for (let option of options) {
        option.onclick = () => {
            selectBox[index].children[1].style.display = "none";
            console.log(option.parentNode);
            selectBox[index].children[0].children[0].innerHTML =
                option.getAttribute("data-value");
        };
    }
});
