const employeeTable = document.querySelectorAll("table");

const salaryColumn = document.querySelectorAll("tbody tr td:nth-child(9)");
console.log(salaryColumn);
for (let salaryRow of salaryColumn) {
    salaryRow.innerHTML =
        salaryRow.innerHTML + `<span style="font-style:italic;color: #454545;"> (VND)</span>`;
}
