$(".select-trigger").each(function (index, value) {
    $(this).click(function (event) {
        $(this).siblings(".select-options").toggle();
    
        $(".select").each(function (index2) {
            if (index2 !== index) {
                $(this).children(".select-options").hide();
            }
        });
    });
});
$(document).click(function (event) {
    if (!$(event.target).parents().hasClass("dropdown"))
        $(".select").each(function () {
            $(this).children(".select-options").hide();
        });
});
$(".option").click(function (event) {
    $(this).addClass("choosed-option");
    $(this)
        .siblings()
        .each(function () {
            $(this).removeClass("choosed-option");
        });
    $(this)
        .parents(".select-options")
        .siblings(".select-trigger")
        .children("span")
        .text($(this).attr("data-value"));
    $(this).parents(".select-options").hide();
});
