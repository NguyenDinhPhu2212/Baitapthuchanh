const inputWrapper = document.querySelector(".input-information");

inputWrapper.onclick = () => {
    inputWrapper.style.borderColor = "#10B075";
};
inputWrapper.onmouseout = () => {
    inputWrapper.style.borderColor = "#dbdeff";
};
$(".add-employee-button").click(function () {
    $(".employee-information-form").show();
});
