$(".toggle-icon").click(function () {
    $(".navbar-item-text").each(function () {
        console.log($(this));
        if ($(this).css("display") !== "none") {
            $(this).css("display", "none");
            $(".navbar").each(function () {
                $(this).css("width", "60px");
            });
            $(".employee-list-content .display").each(function () {
                $(this).css("max-width", "calc(100% - 60px)");
            });
        } else {
            $(this).css("display", "block");
            $(".navbar").each(function () {
                $(this).css("width", "226px");
            });
            $(".employee-list-content .display").each(function () {
                $(this).css("max-width", "calc(100% - 226px)");
            });
        }
    });
});
$(".exit-button").click(function () {
    $(".employee-information-form").hide();
});
$(".destroy-button").click(function(){
    $(".employee-information-form").hide();
})