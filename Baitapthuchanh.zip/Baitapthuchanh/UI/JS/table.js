import { InsertDataToTable , InsertDataToForm} from "./utils.js";
export function FormatSalaryRow() {
    $("tbody tr td:nth-child(9)").each(function () {
        $(this).html(
            $(this).html() +
                `<span style="font-style:italic;color: #454545;"> (VND)</span>`
        );
    });
}
export function LoadDataFromUrl(url) {
    $.ajax({
        url: url,
        success: function (result) {
            result.forEach((value, index) => {
                InsertDataToTable(value);
            });
            FormatSalaryRow();
        },
    });
}
LoadDataFromUrl("http://cukcuk.manhnv.net/v1/Employees");

$("tbody tr").each((function(index, element){
    $(this).click((function(event){

    }))
}))
InsertDataToForm();