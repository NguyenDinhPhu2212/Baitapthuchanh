export function FormatDate(date) {
    let formatedDate = "";
    let response = new Date(date);
   
    if(response.getDate() < 10) formatedDate += "0";
    formatedDate += response.getDate();
    if(response.getMonth() < 9) formatedDate += "/0";
    else formatedDate += "/"
    formatedDate += response.getMonth()+1;
    formatedDate += "/" + response.getFullYear();
    return formatedDate;
}
export function TrainingData(object) {
    for (let attribute in object) {
        if (object[attribute] === null) {
            object[attribute] = "";
            continue;
        } else if (attribute === "JoinDate") {
            object.JoinDate = FormatDate(object.JoinDate);
        } else if (attribute === "DateOfBirth") {
            object.DateOfBirth = FormatDate(object.DateOfBirth);
        }
    }
    return object;
}
export function CreateRowTable(object) {
    object = TrainingData(object);
    return $(`<tr>
            <td>${object.EmployeeCode}</td>
            <td>${object.FullName}</td>
            <td>${object.GenderName}</td>
            <td>${object.DateOfBirth}</td>
            <td>${object.PhoneNumber}</td>
            <td>${object.Email}</td>
            <td>${object.PositionName}</td>
            <td>${object.DepartmentName}</td>
            <td>${object.Salary}</td>
            <td>${object.WorkStatus}</td>
            </tr>`);
}
export function InsertDataToTable(object) {
    $("tbody").append(CreateRowTable(object));
}
export function InsertDataToForm(object){
    object = TrainingData(object);
    console.log($(".general-information-form")[0]["employee-code"].value)
}