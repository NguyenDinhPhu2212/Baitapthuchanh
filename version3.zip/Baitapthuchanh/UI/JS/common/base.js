import { insertDataToTable } from "../table.js";
export default class BaseJS {
    constructor() {
        this.getDataURL = null;
        this.tableElement = null;
        this.setDataURL();
        this.setTableJquery();
        this.loadData();
    }
    setDataURL() {}
    setTableJquery() {}
    /**
     * Lấy dữ liệu từ api
     */
    loadData() {
        let getDataUrl = this.getDataURL;
        let tableElement = this.tableElement;
        tableElement.children("tbody").empty();
        let ajaxCall = $.ajax({
            method: "GET",
            url: getDataUrl,
        });
        ajaxCall.done(function (result) {
            result.forEach((value, index) => {
                insertDataToTable(tableElement, value);
            });
            sessionStorage.setItem(
                "employee-information",
                JSON.stringify(result)
            );
        });
        ajaxCall.fail(function (jqXHR, textStatus, errorThrown) {
            // Nếu thất bại
            console.log(textStatus + ": " + errorThrown);
        });
    }
    add() {}
    update() {}
    delete() {}
}
