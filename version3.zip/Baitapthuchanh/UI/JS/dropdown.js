//cài đặt sự kiện khi click vào các select
$(".select-trigger").each(function (index, value) {
    $(this).click(function (event) {
        $(this).siblings(".select-options").toggle();

        $(".select").each(function (index2) {
            if (index2 !== index) {
                $(this).children(".select-options").hide();
            }
        });
    });
});
$(document).click(function (event) {
    if (!$(event.target).parents().hasClass("dropdown"))
        $(".select").each(function () {
            $(this).children(".select-options").hide();
        });
});
//sựu kiện xảy ra khi nhấn lựa chọn option
$(".option").click(function (event) {
    $(this).addClass("choosed-option");
    let selectTrigger = $(this)
        .parents(".select-options")
        .siblings(".select-trigger");

    selectTrigger.val($(this).attr("data-value"));
    $(this)
        .siblings()
        .each(function () {
            $(this).removeClass("choosed-option");
        });
    selectTrigger.children("span").text($(this).attr("data-value"));
    $(this).parents(".select-options").hide();
});
