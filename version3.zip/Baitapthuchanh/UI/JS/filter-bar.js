import { Employee } from "./page/employee.js";
const inputWrapper = document.querySelector(".input-information");

inputWrapper.onclick = () => {
    inputWrapper.style.borderColor = "#10B075";
};
inputWrapper.onmouseout = () => {
    inputWrapper.style.borderColor = "#dbdeff";
};
$(".refresh-btn").click(function () {
    new Employee();
});
