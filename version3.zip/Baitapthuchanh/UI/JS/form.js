import { insertDataToTable, updateOrInsertData } from "./table.js";

const employeeInformationForm = $(".employee-information-form");
const generalInformationForm = $(".general-information-form")[0];
const jobInformationForm = $(".job-information-form")[0];

//Dropdown
const genderDropdown = $("#genderDropdown");
const positionDropdown = $("#positionDropdown");
const departmentDropdown = $("#departmentDropdown");
const workStatusDropdown = $("#workStatusDropdown");

//cài đặt event cho các input
$(".default-size > #basic-salary").focus(function () {
    $(this).parents(".default-size").toggleClass("salary-focus");
});
$(".default-size > #basic-salary").mouseout(function () {
    $(this).parents(".default-size").removeClass("salary-focus");
    $(this).blur();
});
$(".default-size").mouseout(function () {
    $(this).css("border", " 1px solid #e5e5e5");
    $(this).blur();
});
//làm mới form
export function refreshForm() {
    employeeInformationForm.find("input").val("");
    employeeInformationForm.find(".option").removeClass("choosed-option");

    genderDropdown.children(".select-trigger").val("");
    positionDropdown.children(".select-trigger").val("");
    departmentDropdown.children(".select-trigger").val("");
    workStatusDropdown.children(".select-trigger").val("");

    employeeInformationForm
        .find(".select-trigger")
        .each(function (index, element) {
            $(this)
                .children("span")
                .text(
                    $(this)
                        .siblings(".select-options")
                        .children(".option")
                        .first()
                        .text()
                );
        });
    $(".input-required").removeClass("notice-border");
    $(".notice").hide();
}
//format date
function formmatDate(date) {
    let formatedDate = "";
    if (!date) {
        return "";
    }
    let array = date.split("/");
    formatedDate = array[2] + "-" + array[1] + "-" + array[0];
    return formatedDate;
}
//setup dữ liệu cho dropdown
function setupDropdown(jqueryElement, option) {
    jqueryElement.find(".select-trigger").val(option);
    jqueryElement.find(".select-trigger > span").text(option);
    jqueryElement.find(".option").each(function (index, element) {
        if ($(this).attr("data-value") === option) {
            $(this).addClass("choosed-option");
        }
    });
}
//hiển thị dữ liệu vào form
export function insertDataToForm(object) {
    //thông tin chung
    $("#employee-code").val(object.EmployeeCode);
    $("#employee-name").val(object.FullName);
    $("#date-of-birth").val(FormmatDate(object.DateOfBirth));
    setupDropdown(genderDropdown, object.GenderName);
    $("#identity-code").val(object.IdentityNumber);
    $("#date-of-issue").val(FormmatDate(object.IdentityDate));
    $("#issued-by").val(object.IdentityPlace);
    $("#email").val(object.Email);
    $("#phone-number").val(object.PhoneNumber);

    //thông tin công việc
    setupDropdown(positionDropdown, object.PositionName);
    setupDropdown(departmentDropdown, object.DepartmentName);
    $("#personal-tax-code").val(object.PersonalTaxCode);
    $("#date-of-joining").val(object.JoinDate);
    $("#basic-salary").val(object.Salary);
    setupDropdown(workStatusDropdown, object.WorkStatus);
}
//lấy dữ liệu được điền vào form
export function getDataFromForm() {
    let data = {};

    //thông tin chung
    // data.EmployeeCode = generalInformationForm["employee-code"].value;
    data.EmployeeCode = $("#employee-code").val();
    data.FullName = $("#employee-name").val();
    data.DateOfBirth = $("#date-of-birth").val();
    data.GenderName = $("#gender").val();
    data.IdentityNumber = $("#identity-code").val();
    data.IdentityDate = $("#date-of-issue").val();
    data.IdentityPlace = $("#issued-by").val();
    data.Email = $("#email").val();
    data.PhoneNumber = $("#phone-number").val();

    //thông tin công việc
    data.PositionName = $("#position").val();
    data.DepartmentName = $("#department").val();
    data.PersonalTaxCode = $("#personal-tax-code").val();
    data.Salary = $("#basic-salary").val();
    data.JoinDate = $("#date-of-joining").val();
    data.WorkStatus = $("#job-status").val();
    return data;
}
