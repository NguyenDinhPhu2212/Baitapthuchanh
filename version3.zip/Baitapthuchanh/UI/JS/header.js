//cài đặt sự kiện cho toogle button
$(".toggle-icon").click(function () {
    $(".navbar-item-text").each(function () {
        if ($(this).css("display") !== "none") {
            $(this).css("display", "none");
            $(".navbar").each(function () {
                $(this).css("width", "60px");
            });
            $(".employee-list-content .display").each(function () {
                $(this).css("max-width", "calc(100% - 60px)");
            });
        } else {
            $(this).css("display", "block");
            $(".navbar").each(function () {
                $(this).css("width", "226px");
            });
            $(".employee-list-content .display").each(function () {
                $(this).css("max-width", "calc(100% - 226px)");
            });
        }
    });
});