import BaseJS from "../common/base.js";
import { refreshForm, getDataFromForm } from "../form.js";
import { updateOrInsertData } from "../table.js";
import { validateEmail, validateForm } from "../utils.js";

export class Employee extends BaseJS {
    constructor() {
        super();
        this.initEvents();
    }
    setDataURL() {
        this.getDataURL = "http://cukcuk.manhnv.net/v1/Employees";
    }
    setTableJquery() {
        this.tableElement = $("#employee-table");
    }
    initEvents() {
        let tableElement = this.tableElement;
        //cài đặt sự kiện khi nhấn nút thêm mới nhân viên
        $(".add-employee-button").click(function () {
            $(".employee-information-form").show();
        });
        //kiểm tra tính hợp lệ của địa chỉ email khi nhập
        $("#email").blur(function () {
            let emailAddress = $(this).val();
            if (!validateEmail(emailAddress)) {
                $(this).addClass("notice-border");
            }
        });
        //cài đặt event cho các button trong form
        $(".save-button").click(function (event) {
            if (ValidateForm()) {
                let data = getDataFromForm();
                updateOrInsertData(tableElement,data);
                $(".employee-information-form").hide();
                refreshForm();
            }
        });
        $(".exit-button").click(function () {
            $(".employee-information-form").hide();
            refreshForm();
        });
        $(".destroy-button").click(function () {
            $(".employee-information-form").hide();
            refreshForm();
        });
        //cài đặt sự kiện cho toogle button
        $(".toggle-icon").click(function () {
            $(".navbar-item-text").each(function () {
                if ($(this).css("display") !== "none") {
                    $(this).css("display", "none");
                    $(".navbar").each(function () {
                        $(this).css("width", "60px");
                    });
                    $(".employee-list-content .display").each(function () {
                        $(this).css("max-width", "calc(100% - 60px)");
                    });
                } else {
                    $(this).css("display", "block");
                    $(".navbar").each(function () {
                        $(this).css("width", "226px");
                    });
                    $(".employee-list-content .display").each(function () {
                        $(this).css("max-width", "calc(100% - 226px)");
                    });
                }
            });
        });
    }
}
