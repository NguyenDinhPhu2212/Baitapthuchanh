import { insertDataToForm } from "./form.js";
import { trainingData } from "./utils.js";
import { Employee } from "./page/employee.js";
$(document).ready(function () {
    new Employee();
});
/**
 *
 * @param {*} table
 * @param {*} object
 * @returns
 */
export function createRowTable(table, object) {
    object = trainingData(object);
    let newRow = $("<tr></tr>");
    table
        .children("thead")
        .children("tr")
        .children("th")
        .each(function (columnIndex, columnElement) {
            let fieldName = columnElement.getAttribute("fieldname");
            let value = object[fieldName];
            if (fieldName != "Salary") newRow.append(`<td>${value}</td>`);
            else
                newRow.append(
                    `<td>${value}<span style="font-style:italic;color: #454545;"> (VND)</span></td>`
                );
        });
    newRow.click(function (event) {
        $(".employee-information-form").show();
        insertDataToForm(object);
    });
    return newRow;
}
//thêm dữ liệu vào bảng
export function insertDataToTable(table, object) {
    let element = createRowTable(table, object);
    table.children("tbody").append(element);
}
//Kiểm tra dữ liệu đã tồn tại hay chưa
//Nếu không, thêm mới vào bảng
//Nếu đã tồn tại thì cập nhật
export function updateOrInsertData(table, object) {
    const originData = JSON.parse(
        sessionStorage.getItem("employee-information")
    );
    let index = originData.findIndex((value, index) => {
        return value.EmployeeCode === object.EmployeeCode;
    });
    if (index < 0) {
        insertDataToForm(table, object);
    } else {
        let newRow = createRowTable(table, object);
        table
            .children(`tbody`)
            .children(`tr:nth-child(${index + 1})`)
            .replaceWith(newRow);
    }
}

