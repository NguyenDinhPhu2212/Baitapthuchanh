/**
 * Định dạng ngày thành chuỗi dạng "dd/mm/yyyy"
 * @param {*} date : chuỗi ngày cần định dạng
 * @returns 
 */
export function formatDate(date) {
    let formatedDate = "";
    let response = new Date(date);
    if (!date) {
        return "";
    }
    if (response.getDate() < 10) formatedDate += "0";
    formatedDate += response.getDate();
    if (response.getMonth() < 9) formatedDate += "/0";
    else formatedDate += "/";
    formatedDate += response.getMonth() + 1;
    formatedDate += "/" + response.getFullYear();
    return formatedDate;
}

const convertGender = {
    0: "Nữ",
    1: "Nam",
    other: "Khác",
};
const convertWorkStatus = {
    0: "Đang làm việc",
    1: "Đang thử việc",
    2: "Đã nghỉ",
    3: "Khác",
};
/**
 * Tranning dữ liệu nhận được từ api
 * @param {*} object : object cần training
 * @returns object đã được train
 */
export function trainingData(object) {
    for (let attribute in object) {
        if (!object[attribute]) {
            object[attribute] = "";
            continue;
        } else {
            switch (attribute) {
                case "JoinDate":
                    object.JoinDate = formatDate(object.JoinDate);
                    break;
                case "DateOfBirth":
                    object.DateOfBirth = formatDate(object.DateOfBirth);
                    break;
                case "Gender":
                    parseInt(object.Gender) > 1
                        ? (object.GenderName = convertGender["other"])
                        : (object.GenderName = convertGender[object.Gender]);
                    break;
                case "WorkStatus":
                    object.WorkStatus = convertWorkStatus[object.WorkStatus];
                    break;
                case "Salary":
                    object.Salary = object.Salary.toLocaleString("it-IT");
                    break;
            }
        }
    }
    return object;
}
//kiểm tra trường thông tin hợp lệ hay không
export function validateEmail(emailAddress) {
    const emailReg =
        /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return emailReg.test(emailAddress);
}
export function validateForm() {
    let response = true;
    $(".input-required").each(function (index, element) {
        if (!$(this).val()) {
            $(this).addClass("notice-border");
            $(this).parent().find(".notice").show();
            response = false;
        }
    });

    return response;
}
export function postData(){

}